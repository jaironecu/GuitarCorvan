package com.tu.paquete.guitarcorvan

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
// Importación oficial del motor de audio Android que descargamos
import be.tarsos.dsp.AudioDispatcher
import be.tarsos.dsp.io.android.AudioDispatcherFactory

class MainActivity : AppCompatActivity() {

    private val REQUEST_RECORD_AUDIO_PERMISSION = 200
    private var dispatcher: AudioDispatcher? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Verificamos y pedimos el permiso del micrófono al abrir la app
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_RECORD_AUDIO_PERMISSION
            )
        } else {
            iniciarEscuchaDeAudio()
        }
    }

    private fun iniciarEscuchaDeAudio() {
        try {
            // Inicializamos el motor TarsosDSP seguro para Android
            dispatcher = AudioDispatcherFactory.fromDefaultAudioDispatcher(22050, 1024, 0)
            // Aquí puedes conectar tu lógica de afinación más adelante
            // val pitchProcessor = PitchDetectionHandler { res, _ -> ... }
            // dispatcher?.addAudioProcessor(PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050f, 1024, pitchProcessor))
            
            // Thread(dispatcher).start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                Toast.makeText(this, "Permiso de micrófono concedido", Toast.LENGTH_SHORT).show()
                iniciarEscuchaDeAudio()
            } else {
                Toast.makeText(this, "Se necesita el micrófono para afinar la guitarra", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        dispatcher?.stop()
    }
}