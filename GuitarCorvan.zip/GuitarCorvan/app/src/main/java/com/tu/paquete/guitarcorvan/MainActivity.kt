package com.tu.paquete.guitarcorvan

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import be.tarsos.dsp.AudioDispatcher
import be.tarsos.dsp.AudioEvent
import be.tarsos.dsp.io.android.AudioDispatcherFactory
import be.tarsos.dsp.pitch.PitchDetectionHandler
import be.tarsos.dsp.pitch.PitchDetectionResult
import be.tarsos.dsp.pitch.PitchProcessor
import kotlin.math.abs

data class CuerdaObjetivo(val nombreSencillo: String, val frecuenciaHz: Float)

class MainActivity : AppCompatActivity() {

    private val REQUEST_AUDIO_PERM = 200
    private var dispatcher: AudioDispatcher? = null
    private var escuchando = false
    private var ultimoAvisoTiempo = 0L

    private lateinit var tvNotaDetectada: TextView
    private lateinit var tvInstruccion: TextView
    private lateinit var btnEscuchar: Button
    private lateinit var spinnerInstrumento: Spinner
    private lateinit var spinnerAfinacion: Spinner

    private var cuerdasActivas = listOf<CuerdaObjetivo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvNotaDetectada = findViewById(R.id.tvNotaDetectada)
        tvInstruccion = findViewById(R.id.tvInstruccion)
        btnEscuchar = findViewById(R.id.btnEscuchar)
        spinnerInstrumento = findViewById(R.id.spinnerInstrumento)
        spinnerAfinacion = findViewById(R.id.spinnerAfinacion)

        configurarSelectores()

        btnEscuchar.setOnClickListener {
            if (escuchando) {
                detenerAfinador()
            } else {
                verificarPermisosYIniciar()
            }
        }
    }

    private fun configurarSelectores() {
        val instrumentos = listOf("Guitarra (6 cuerdas)", "Bajo (4 cuerdas)")
        val adapterInst = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, instrumentos)
        spinnerInstrumento.adapter = adapterInst

        val afinacionesGuitarra = listOf(
            "Afinación normal (Estándar)",
            "Medio tono más grave (Estilo metal / Eb)",
            "Un tono más grave (Estándar en Re / D)",
            "Afinación Drop D (Cuerda 6 en Re grave)"
        )

        val afinacionesBajo = listOf(
            "Afinación normal (Estándar 4 cuerdas)",
            "Medio tono más grave (Eb)",
            "Afinación Drop D (Cuerda 4 en Re)"
        )

        val adapterAfin = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, afinacionesGuitarra)
        spinnerAfinacion.adapter = adapterAfin

        spinnerInstrumento.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    spinnerAfinacion.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, afinacionesGuitarra)
                } else {
                    spinnerAfinacion.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, afinacionesBajo)
                }
                actualizarFrecuenciasObjetivo()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerAfinacion.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                actualizarFrecuenciasObjetivo()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        actualizarFrecuenciasObjetivo()
    }

    private fun actualizarFrecuenciasObjetivo() {
        val inst = spinnerInstrumento.selectedItemPosition
        val afin = spinnerAfinacion.selectedItemPosition

        cuerdasActivas = if (inst == 0) {
            when (afin) {
                0 -> listOf( // Guitarra Estándar
                    CuerdaObjetivo("Cuerda 6 (Mi grave)", 82.41f),
                    CuerdaObjetivo("Cuerda 5 (La)", 110.00f),
                    CuerdaObjetivo("Cuerda 4 (Re)", 146.83f),
                    CuerdaObjetivo("Cuerda 3 (Sol)", 196.00f),
                    CuerdaObjetivo("Cuerda 2 (Si)", 246.94f),
                    CuerdaObjetivo("Cuerda 1 (Mi agudo)", 329.63f)
                )
                1 -> listOf( // Guitarra Medio Tono Abajo
                    CuerdaObjetivo("Cuerda 6 (Re sostenido grave)", 77.78f),
                    CuerdaObjetivo("Cuerda 5 (Sol sostenido)", 103.83f),
                    CuerdaObjetivo("Cuerda 4 (Do sostenido)", 138.59f),
                    CuerdaObjetivo("Cuerda 3 (Fa sostenido)", 185.00f),
                    CuerdaObjetivo("Cuerda 2 (La sostenido)", 233.08f),
                    CuerdaObjetivo("Cuerda 1 (Re sostenido agudo)", 311.13f)
                )
                2 -> listOf( // Guitarra Un Tono Abajo
                    CuerdaObjetivo("Cuerda 6 (Re grave)", 73.42f),
                    CuerdaObjetivo("Cuerda 5 (Sol)", 98.00f),
                    CuerdaObjetivo("Cuerda 4 (Do)", 130.81f),
                    CuerdaObjetivo("Cuerda 3 (Fa)", 174.61f),
                    CuerdaObjetivo("Cuerda 2 (La)", 220.00f),
                    CuerdaObjetivo("Cuerda 1 (Re agudo)", 293.66f)
                )
                else -> listOf( // Drop D
                    CuerdaObjetivo("Cuerda 6 (Re muy grave)", 73.42f),
                    CuerdaObjetivo("Cuerda 5 (La)", 110.00f),
                    CuerdaObjetivo("Cuerda 4 (Re)", 146.83f),
                    CuerdaObjetivo("Cuerda 3 (Sol)", 196.00f),
                    CuerdaObjetivo("Cuerda 2 (Si)", 246.94f),
                    CuerdaObjetivo("Cuerda 1 (Mi agudo)", 329.63f)
                )
            }
        } else {
            when (afin) {
                0 -> listOf( // Bajo Estándar
                    CuerdaObjetivo("Cuerda 4 (Mi grave)", 41.20f),
                    CuerdaObjetivo("Cuerda 3 (La)", 55.00f),
                    CuerdaObjetivo("Cuerda 2 (Re)", 73.42f),
                    CuerdaObjetivo("Cuerda 1 (Sol)", 98.00f)
                )
                1 -> listOf( // Bajo Medio Tono Abajo
                    CuerdaObjetivo("Cuerda 4 (Re sostenido grave)", 38.89f),
                    CuerdaObjetivo("Cuerda 3 (Sol sostenido)", 51.91f),
                    CuerdaObjetivo("Cuerda 2 (Do sostenido)", 69.30f),
                    CuerdaObjetivo("Cuerda 1 (Fa sostenido)", 92.50f)
                )
                else -> listOf( // Bajo Drop D
                    CuerdaObjetivo("Cuerda 4 (Re muy grave)", 36.71f),
                    CuerdaObjetivo("Cuerda 3 (La)", 55.00f),
                    CuerdaObjetivo("Cuerda 2 (Re)", 73.42f),
                    CuerdaObjetivo("Cuerda 1 (Sol)", 98.00f)
                )
            }
        }
    }

    private fun verificarPermisosYIniciar() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO_PERM)
        } else {
            iniciarAfinador()
        }
    }

    private fun iniciarAfinador() {
        try {
            dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050, 1024, 0)

            val handler = PitchDetectionHandler { result: PitchDetectionResult, _: AudioEvent ->
                val pitch = result.pitch
                if (pitch != -1f && pitch > 30f && pitch < 1000f) {
                    runOnUiThread { procesarFrecuencia(pitch) }
                }
            }

            val pitchProcessor = PitchProcessor(
                PitchProcessor.PitchEstimationAlgorithm.YIN,
                22050f,
                1024,
                handler
            )

            dispatcher?.addAudioProcessor(pitchProcessor)
            Thread(dispatcher, "Audio Dispatcher").start()

            escuchando = true
            btnEscuchar.text = "Detener afinador"
            btnEscuchar.contentDescription = "Botón para pausar afinador"
            tvInstruccion.text = "Escuchando... Toca una sola cuerda"
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error al acceder al micrófono", Toast.LENGTH_SHORT).show()
        }
    }

    private fun procesarFrecuencia(frecuenciaActual: Float) {
        if (cuerdasActivas.isEmpty()) return

        var cuerdaCercana = cuerdasActivas[0]
        var menorDiferencia = abs(frecuenciaActual - cuerdaCercana.frecuenciaHz)

        for (cuerda in cuerdasActivas) {
            val dif = abs(frecuenciaActual - cuerda.frecuenciaHz)
            if (dif < menorDiferencia) {
                menorDiferencia = dif
                cuerdaCercana = cuerda
            }
        }

        val diferencia = frecuenciaActual - cuerdaCercana.frecuenciaHz
        val margenAfinado = 1.2f

        val instruccionTexto: String
        if (abs(diferencia) <= margenAfinado) {
            instruccionTexto = "¡Perfecto! Cuerda afinada."
        } else if (diferencia < 0) {
            instruccionTexto = "Sonido grave: Aprieta o tensa un poco la cuerda."
        } else {
            instruccionTexto = "Sonido agudo: Afloja un poco la cuerda."
        }

        tvNotaDetectada.text = cuerdaCercana.nombreSencillo
        tvInstruccion.text = instruccionTexto

        // Notificación para lectores de pantalla cada 2 segundos para evitar saturación de voz
        val ahora = System.currentTimeMillis()
        if (ahora - ultimoAvisoTiempo > 2000) {
            ultimoAvisoTiempo = ahora
            tvInstruccion.announceForAccessibility("${cuerdaCercana.nombreSencillo}. $instruccionTexto")
        }
    }

    private fun detenerAfinador() {
        dispatcher?.stop()
        dispatcher = null
        escuchando = false
        btnEscuchar.text = "Iniciar afinador"
        btnEscuchar.contentDescription = "Botón para iniciar afinador"
        tvInstruccion.text = "Afinador en pausa"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO_PERM && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            iniciarAfinador()
        } else {
            Toast.makeText(this, "Se necesita permiso del micrófono para afinar", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        detenerAfinador()
    }
}