package com.tu.paquete.guitarcorvan

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import be.tarsos.dsp.AudioDispatcher
import be.tarsos.dsp.io.android.AudioDispatcherFactory
import be.tarsos.dsp.pitch.PitchDetectionHandler
import be.tarsos.dsp.pitch.PitchProcessor
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log2
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var mediaPlayer: MediaPlayer
    private var dispatcher: AudioDispatcher? = null
    private var isListening = false
    private var lastSpokenTime: Long = 0
    private var frecuenciasActuales: List<Double> = emptyList()

    private val perfilesInstrumentos = mapOf(
        "Violín" to listOf(196.00, 293.66, 440.00, 659.25),
        "Ukelele" to listOf(392.00, 261.63, 329.63, 440.00),
        "Guitarra Clásica" to listOf(82.41, 110.00, 146.83, 196.00, 246.94, 329.63),
        "Guitarra Electroacústica" to listOf(82.41, 110.00, 146.83, 196.00, 246.94, 329.63),
        "Guitarra Eléctrica" to listOf(82.41, 110.00, 146.83, 196.00, 246.94, 329.63)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "Guitar Corvan"

        tts = TextToSpeech(this, this)
        mediaPlayer = MediaPlayer.create(this, R.raw.campana)

        configurarSelector()
        configurarBoton()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val localSpanish = Locale("es", "ES")
            tts.language = localSpanish
        }
    }

    private fun configurarSelector() {
        val selector = findViewById<Spinner>(R.id.selectorInstrumento)
        val nombresInstrumentos = perfilesInstrumentos.keys.toList()
        
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, nombresInstrumentos)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        selector.adapter = adapter

        selector.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val instrumentoSeleccionado = nombresInstrumentos[position]
                frecuenciasActuales = perfilesInstrumentos[instrumentoSeleccionado] ?: emptyList()
                hablar("Instrumento seleccionado: $instrumentoSeleccionado", forzar = true)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun configurarBoton() {
        val boton = findViewById<Button>(R.id.botonAfinar)
        val textoEstado = findViewById<TextView>(R.id.textoEstado)

        boton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                return@setOnClickListener
            }

            if (isListening) {
                detenerAfinacion()
                boton.text = "Iniciar afinación"
                textoEstado.text = "Estado: Detenido"
                hablar("Afinación detenida", forzar = true)
            } else {
                iniciarAfinacion()
                boton.text = "Detener afinación"
                textoEstado.text = "Estado: Escuchando"
                hablar("Afinador activado, toque una cuerda", forzar = true)
            }
            isListening = !isListening
        }
    }

    private fun iniciarAfinacion() {
        dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050, 1024, 0)
        
        val pdh = PitchDetectionHandler { result, _ ->
            val pitchInHz = result.pitch
            if (pitchInHz > 0) {
                procesarFrecuencia(pitchInHz.toDouble())
            }
        }
        
        val pitchProcessor = PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.YIN, 22050f, 1024, pdh)
        dispatcher?.addAudioProcessor(pitchProcessor)
        Thread(dispatcher, "Audio Dispatcher").start()
    }

    private fun detenerAfinacion() {
        dispatcher?.stop()
        dispatcher = null
    }

    private fun procesarFrecuencia(pitchDetectado: Double) {
        if (frecuenciasActuales.isEmpty()) return

        var frecuenciaObjetivo = frecuenciasActuales[0]
        var minimaDiferencia = Double.MAX_VALUE

        for (frecuencia in frecuenciasActuales) {
            val diferencia = abs(pitchDetectado - frecuencia)
            if (diferencia < minimaDiferencia) {
                minimaDiferencia = diferencia
                frecuenciaObjetivo = frecuencia
            }
        }

        val cents = (1200.0 * log2(pitchDetectado / frecuenciaObjetivo)).roundToInt()

        val tiempoActual = System.currentTimeMillis()
        if (tiempoActual - lastSpokenTime > 2000) { 
            lastSpokenTime = tiempoActual

            runOnUiThread {
                if (cents == 0) {
                    if (!mediaPlayer.isPlaying) {
                        mediaPlayer.start()
                    }
                } else if (cents < 0) {
                    val numeroAbsoluto = abs(cents)
                    hablar("menos $numeroAbsoluto", forzar = false)
                } else {
                    hablar("más $cents", forzar = false)
                }
            }
        }
    }

    private fun hablar(texto: String, forzar: Boolean) {
        if (forzar || !tts.isSpeaking) {
            tts.speak(texto, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (tts != null) {
            tts.stop()
            tts.shutdown()
        }
        mediaPlayer.release()
        detenerAfinacion()
    }
}